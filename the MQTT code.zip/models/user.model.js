const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const { USER_ROLES } = require('../utils/enums');

const userSchema = new Schema({
    email: {
        type: String,
        required: true,
        undefined: true,
        unique: true
    },
    password: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    phoneNumber: {
        type: String,
        default: null
    },
    role: {
        type: String,
        enum: [USER_ROLES.ADMIN, USER_ROLES.OPERATOR, USER_ROLES.MAINTENANCE],
        default: USER_ROLES.MAINTENANCE
    },
    lastLogin: {
        type: Date,
        default: Date.now()
    },
    isVerified: {
        type: Boolean,
        default: false
    },
    resetPasswordToken: String,
    resetPasswordExpiresAt: Date,
    verificationToken: String,
    verificationTokenExpiresAt: Date
}, {timestamps: true});

module.exports = mongoose.model('User', userSchema);